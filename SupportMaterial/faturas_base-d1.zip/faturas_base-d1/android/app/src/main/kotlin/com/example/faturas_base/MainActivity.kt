package com.example.faturas_base

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
